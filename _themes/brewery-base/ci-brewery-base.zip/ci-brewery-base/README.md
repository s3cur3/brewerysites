Theme Name:         The Modern Brewery
Theme URI:          http://brewsites.net/wordpress-themes-for-breweries/
Description:        A clean, modern, responsive theme just for craft breweries & brewpubs.
Version:            1.2.0
Author:             Tyler Young
Author URI:         http://brewsites.net/tyler-young/





For full documentation, open this theme's "docs" directory and open the "modern-brewery-theme-documentation.html" file.

