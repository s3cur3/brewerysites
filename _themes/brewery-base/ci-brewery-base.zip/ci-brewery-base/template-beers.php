<?php
/*
Template Name: All Beers
*/
?>
<!-- TEMPLATE: ALL BEERS -->
<?php get_template_part('templates/page', 'header-archive'); ?>
<?php get_template_part('templates/content', 'beer-archive'); ?>
