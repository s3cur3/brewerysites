<?php
/*
All Staff archive (same as All Staff template)
*/
?>
<!-- STAFF ARCHIVE -->
<?php get_template_part('templates/page', 'header-archive'); ?>
<?php get_template_part('templates/content', 'staff-archive'); ?>
