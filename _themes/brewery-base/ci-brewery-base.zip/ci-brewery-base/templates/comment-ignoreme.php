<?php
/* Wordpress theme uploader requires this: */
comment_form();