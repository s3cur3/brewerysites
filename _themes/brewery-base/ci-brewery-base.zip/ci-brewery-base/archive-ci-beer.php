<?php
/*
All Beers archive (same as All Beers template)
*/
?>
<!-- ARCHIVE-CI-BEER.PHP -->
<?php get_template_part('templates/page', 'header-archive'); ?>
<?php get_template_part('templates/content', 'beer-archive'); ?>
