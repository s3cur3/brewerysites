<?php
/*
Template Name: All Staff
*/
?>
<!-- TEMPLATE: ALL STAFF -->
<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'staff'); ?>
