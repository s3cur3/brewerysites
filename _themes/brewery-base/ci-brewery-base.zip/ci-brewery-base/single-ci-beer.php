<!-- SINGLE STAFF MEMBER -->
<?php get_template_part('templates/page', 'header-beer'); ?>
<?php get_template_part('templates/content', 'beer'); ?>
